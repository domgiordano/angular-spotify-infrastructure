import json


def lambda_handler(event, context):
    # TODO implement
    return {
        'statusCode': 501,
        'body': json.dumps('Lambda not implemented.')
    }
